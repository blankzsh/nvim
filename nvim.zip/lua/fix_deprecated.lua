-- 全局修复vim.tbl_islist废弃警告
if vim.tbl_islist and not vim.islist then
    vim.islist = vim.tbl_islist
end

-- 重新定义vim.tbl_islist来避免警告
local original_tbl_islist = vim.tbl_islist
vim.tbl_islist = function(v)
    -- 使用新的API如果存在的话
    if vim.islist then
        return vim.islist(v)
    end
    return original_tbl_islist(v)
end