local G = require('G')
local M = {}

function M.config()
end

function M.setup()
    local ccc = require('ccc')
    ccc.setup({})
end

return M
